<!--<?php
if(!defined('SABLOG_ROOT')) {
	exit('Access Denied');
}
print <<<EOT
-->
<div id="footer"><p class="ellpa"><a href="http://www.shadowsky.cn/yz/?p=174"><img src="templates/$options[templatename]/img/elppa.jpg" border=0 alt="Ellpa_ShadowSky.cn" target="_blank" /></a></p><p class="copyright">Except where otherwise noted, this site is licensed under a <a href="http://creativecommons.org/licenses/by-nc-sa/2.5/deed.zh" target="_blank">Creative Commons License</a>.<br />Supported by <a href="http://www.4ngel.net" target="_blank">Security Angel Team</a>. Powered by <a href="http://www.sablog.net" target="_blank">SaBlog-X</a>.Skin by <a href="http://www.shadowsky.cn" title="源子" target="_blank">Shadow</a>.<br />Copyright &copy; <a href="$options[url]">$options[name]</a> All rights reserved.<!--
EOT;
if($options['icp']){print <<<EOT
-->
<a href="http://www.miibeian.gov.cn/" target="_blank">$options[icp]</a><!--
EOT;
if($options['show_debug']){print <<<EOT
--><br />$sa_debug<!--
EOT;
}
print <<<EOT
--> <a href="http://validator.w3.org/check?uri=referer" target="_blank">XHTML 1.0</a>. <a href="post.php?action=clearcookies">清除Cookies</a>.
<!--
EOT;
}print <<<EOT
-->
</p>
</div>
</div>
</body></html><!--
EOT;
?>-->