<?php
/**
 * Template Name: Blog
 * Description: Blog
 *
 * @package WordPress
 * @subpackage Twenty_Eleven
 * @since Twenty Eleven 1.0
 */

get_header(); ?>

		<div id="primary" class="showcase">
			<div id="content" role="main">

<?php
$previous_year = $year = 0;
$previous_month = $month = 0;
$ul_open = false;

$myposts = get_posts('numberposts=-1&orderby=post_date&order=DESC');
?>

<?php foreach($myposts as $post) : ?>

<?php
setup_postdata($post);
$year = mysql2date('Y', $post->post_date);
$month = mysql2date('n', $post->post_date);
$day = mysql2date('j', $post->post_date);
?>

<?php if($year != $previous_year || $month != $previous_month) : ?>

<?php if($ul_open == true) : ?>
</ul>
<?php endif; ?>

<h3 style="border-bottom:1px dashed #ccc;font-size:12px;font-weight:bold;color:#10d3fc;"><?php the_time('Y|M'); ?></h3>
<ul>
<?php $ul_open = true; ?>
<?php endif; ?>
<?php $previous_year = $year; $previous_month = $month; ?>

<li style="list-style:none;border-bottom:1px solid #ddd;font-size:12px;line-height:25px;">
<span style="color:#888;font-size:10px;"><?php the_time('Y/m/d'); ?></span> 
<span><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></span> 
<!--<span style="color:#888;font-size:10px;">&nbsp;<?php if(function_exists('the_views')) { the_views(); } ?></span> <?php comments_popup_link( __( '(0)', 'farlee' ), __( '(1)', 'farlee' ), __( '(%)', 'farlee' ), 'comments-link', __('^', 'farlee')); ?> -->

</li>

<?php endforeach; ?>
</ul>
			</div><!-- #content -->
		</div><!-- #primary -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>