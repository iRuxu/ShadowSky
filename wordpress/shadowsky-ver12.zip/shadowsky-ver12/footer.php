<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the id=main div and all content after
 *
 * @package WordPress
 * @subpackage Twenty_Eleven
 * @since Twenty Eleven 1.0
 */
?>
	</div><!-- #yz-content -->
	</div><!-- #scroll-control -->
	</div><!-- #main -->
	<footer id="colophon" role="contentinfo">
	
	<!--底部杂项导航开始-->
<div id="lang"><span style="font-size:11px;color:#777;text-transform: uppercase;"></span> 
				<a href="http://translate.google.com/translate?hl=zh-CN&sl=en&tl=zh-CN&u=http%3A%2F%2Fwww.shadowsky.cn%2F" target="_blank"><img src="http://www.shadowsky.cn/img/lang/China.jpg" alt="简体中文" title="简体中文" /></a> 
<a href="http://translate.google.com/translate?hl=zh-CN&sl=zh-CN&tl=zh-TW&u=http%3A%2F%2Fwww.shadowsky.cn%2F" target="_blank"><img src="http://www.shadowsky.cn/img/lang/Hong-Kong.jpg" alt="繁体中文" title="繁体中文" /></a> 
<a href="http://translate.google.com/translate?hl=zh-CN&sl=zh-CN&tl=en&u=http%3A%2F%2Fwww.shadowsky.cn%2F" target="_blank"><img src="http://www.shadowsky.cn/img/lang/English.jpg" alt="English" title="English" /></a> 
<a href="http://translate.google.com/translate?hl=zh-CN&sl=zh-CN&tl=ko&u=http%3A%2F%2Fwww.shadowsky.cn%2F" target="_blank"><img src="http://www.shadowsky.cn/img/lang/Korea.jpg" alt="한국의" title="한국의" /></a> 
<a href="http://translate.google.com/translate?hl=zh-CN&sl=zh-CN&tl=ja&u=http%3A%2F%2Fwww.shadowsky.cn%2F" target="_blank"><img src="http://www.shadowsky.cn/img/lang/Japan.jpg" alt="日本の言語" title="日本の言語"/></a> 
<a href="http://translate.google.com/translate?hl=zh-CN&sl=zh-CN&tl=it&u=http%3A%2F%2Fwww.shadowsky.cn%2F" target="_blank"><img src="http://www.shadowsky.cn/img/lang/Italic.jpg" alt="italiano" title="italiano"/></a> 
<a href="http://translate.google.com/translate?hl=zh-CN&sl=zh-CN&tl=es&u=http%3A%2F%2Fwww.shadowsky.cn%2F" target="_blank"><img src="http://www.shadowsky.cn/img/lang/Spain.jpg" alt="español" title="español"/></a> 
<a href="http://translate.google.com/translate?hl=zh-CN&sl=zh-CN&tl=pt&u=http%3A%2F%2Fwww.shadowsky.cn%2F" target="_blank"><img src="http://www.shadowsky.cn/img/lang/Portugal.jpg" alt="português" title="português"/></a> 
<a href="http://translate.google.com/translate?hl=zh-CN&sl=zh-CN&tl=de&u=http%3A%2F%2Fwww.shadowsky.cn%2F" target="_blank"><img src="http://www.shadowsky.cn/img/lang/Germany.jpg" alt="Deutsch" title="Deutsch"/></a> 
<a href="http://translate.google.com/translate?hl=zh-CN&sl=zh-CN&tl=fr&u=http%3A%2F%2Fwww.shadowsky.cn%2F" target="_blank"><img src="http://www.shadowsky.cn/img/lang/France.jpg" alt="française" title="française"/></a> 
<a href="http://translate.google.com/translate?hl=zh-CN&sl=zh-CN&tl=ru&u=http%3A%2F%2Fwww.shadowsky.cn%2F" target="_blank"><img src="http://www.shadowsky.cn/img/lang/Russia.jpg" alt="русский" title="русский"/></a>
<a href="http://translate.google.com/translate?hl=zh-CN&sl=zh-CN&tl=vi&u=http%3A%2F%2Fwww.shadowsky.cn%2F" target="_blank"><img src="http://www.shadowsky.cn/img/lang/Vietnam.jpg" alt="Việt" title="Việt"/></a></div>
 <div id="site-generator">
Copyright ©1999-2014 www.ShadowSky.cn All rights reserved.
</div>
<div id="footer-nav">
<a href="http://www.shadowsky.cn" title="首页">Home</a> ／ 
<a href="http://www.shadowsky.cn/blog" title="归档">Archive</a> ／ 
<a href="http://www.shadowsky.cn/feed" target="_blank" title="Feed">RSS</a> ／
<a href="http://www.shadowsky.cn/sitemap.xml" target="_blank" title="Sitemap">XML</a> ／
<a href="http://www.shadowsky.cn/yz/" title="关于">About</a> ／ 
<a href="http://weibo.com/yuanzi0512" title="联系">Contact</a> ／ 
<a href="http://www.shadowsky.cn/yz/links" title="Bookmark">Link</a> 
			<div id="footermisc" style="display:none;">
					<?php if ( ! dynamic_sidebar( 'footermisc' ) ) : ?>

						<?php
						the_widget( 'Twenty_Eleven_Ephemera_Widget', '', array( 'before_title' => '<h3 class="widget-title">', 'after_title' => '</h3>' ) );
						?>

					<?php endif; // end sidebar widget area ?>
				</div><!-- .widget-area -->


</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>
</div>
</body>
</html>