<?php
/**
 * Displays all of the <head> section and everything up till <div id="main">
 */
?><!DOCTYPE html>
<!--[if IE 6]>
<html id="ie6" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 7]>
<html id="ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html id="ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 6) | !(IE 7) | !(IE 8)  ]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<meta name="viewport" content="width=device-width" />
<meta property="qc:admins" content="13623467776301477331636" />
<meta name="keywords" content="源子,ShadowSky,Shadow,浮烟,淡笑浮烟,莯兜" />
<meta name="description" content="Photoshop,Coreldraw,3Dmax,Flash,AfterEffects,Premiere,CorelVideoStudio,Font download,etc." />
<title><?php
	/*
	 * Print the <title> tag based on what is being viewed.
	 */
	global $page, $paged;

	wp_title( '|', true, 'right' );

	// Add the blog name.
	bloginfo( 'name' );

	// Add the blog description for the home/front page.
	$site_description = get_bloginfo( 'description', 'display' );
	if ( $site_description && ( is_home() || is_front_page() ) )
		echo " | $site_description";

	// Add a page number if necessary:
	if ( $paged >= 2 || $page >= 2 )
		echo ' | ' . sprintf( __( 'Page %s', 'twentyeleven' ), max( $paged, $page ) );

	?></title>
<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<!--[if lt IE 9]>
<script src="<?php echo get_template_directory_uri(); ?>/js/html5.js" type="text/javascript"></script>
<![endif]-->
<?php
	/* We add some JavaScript to pages with the comment form
	 * to support sites with threaded comments (when in use).
	 */
	if ( is_singular() && get_option( 'thread_comments' ) )
		wp_enqueue_script( 'comment-reply' );

	/* Always have wp_head() just before the closing </head>
	 * tag of your theme, or you will break many plugins, which
	 * generally use this hook to add elements to <head> such
	 * as styles, scripts, and meta tags.
	 */
	wp_head();
?>
<!--scrollbar js-->
<script language='javascript' src='<?php echo esc_url( home_url( '/' ) ); ?>js/jquery.js'></script>
<script language='javascript' src='<?php echo esc_url( home_url( '/' ) ); ?>js/jscroll.js'></script>
<script type="text/javascript"> 
$(document).ready(function(){
	$("#scroll-control").jscroll({ W:"20px"//设置滚动条宽度
					,BgUrl:"url(http://www.shadowsky.cn/img/scroll.png)"//设置滚动条背景图片地址
					,Bg:"right 0 repeat-y"//设置滚动条背景图片位置,平铺方式等
					,Bar:{Bd:{Out:"#ffffff",Hover:"#fffff"}//设置滚动滚轴边框颜色:鼠标离开默认与经过(可略)
						 ,Bg:{Out:"-40px 0",Hover:"-20px 0",Focus:"-80px 0"}}//设置滚动滚轴背景:鼠标离开(默认),经过,点击
					,Btn:{btn:false//是否显示上下按钮,true/false
						 ,uBg:{Out:"0 0",Hover:"-15px 0",Focus:"-30px 0"}//设置上按钮背景：鼠标离开(默认)，经过，点击
						 ,dBg:{Out:"0 -15px",Hover:"-15px -15px",Focus:"-30px -15px"}}//设置下按钮背景：鼠标离开(默认)，经过，点击
					,Fn:function(){}//滚动时候触发的方法
					});
 });
</script>
</head>

<body>
<div id="shadowsky">
<div id="shadowsky-page" class="hfeed">
<header>
<div id="shadowsky-logo"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="ShadowSky"></a></div>
</header>
	<div id="main">
	<div id="scroll-control" style="width:710px;height:460px;">
		<div id="yz-content">