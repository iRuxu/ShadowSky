<!--<?php
if(!defined('SABLOG_ROOT')) {
	exit('Access Denied');
}
print <<<EOT
-->
<p><b>未定义操作</b></p>
<p><a href="$options[url]">返回</a></p>
<!--
EOT;
?>