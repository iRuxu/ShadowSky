<p>Error 404 - Not Found,Please Back ○o(∩_∩)o○ <a href="<?php echo get_option('home'); ?>/">[Go back now]</a></p>
