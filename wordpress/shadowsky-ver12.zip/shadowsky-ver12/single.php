<?php
/**
 * The Template for displaying all single posts.
 *
 * @package WordPress
 * @subpackage Twenty_Eleven
 * @since Twenty Eleven 1.0
 */

get_header(); ?>
<div id="page-content">
			<div id="contentx-page" role="main">
				<?php while ( have_posts() ) : the_post(); ?>
					<?php get_template_part( 'content', 'single' ); ?>
			</div><!-- #content -->
</div><!-- #page-content -->	
            <!--<div id="wumiiDisplayDiv" style="width:95%;margin-left:3%;"></div>-->
	        <div id="yz-sg-entry-meta">
                Date: <?php the_date(); ?> |
                Author: <?php the_author(); ?>  |
			    Category: <?php the_category(’, ‘) ?> |
                <?php the_tags('Tags: ',' • '); ?>
	        </div><!-- .entry-meta -->
            <div id="yz-search"><?php get_search_form(); ?></div><!--search-->
			<div id="home-widget">
			   <div id="widget-1" class="yz-widget" role="complementary">
					<?php if ( ! dynamic_sidebar( 'sidebar-1' ) ) : ?>

						<?php
						the_widget( 'Twenty_Eleven_Ephemera_Widget', '', array( 'before_title' => '<h3 class="widget-title">', 'after_title' => '</h3>' ) );
						?>

					<?php endif; // end sidebar widget area ?>
			   </div><!-- .widget-area -->

               <div id="widget-2" class="yz-widget" role="complementary">
					<?php if ( ! dynamic_sidebar( 'sidebar-2' ) ) : ?>

						<?php
						the_widget( 'Twenty_Eleven_Ephemera_Widget', '', array( 'before_title' => '<h3 class="widget-title">', 'after_title' => '</h3>' ) );
						?>

					<?php endif; // end sidebar widget area ?>
			   </div><!-- .widget-area -->

			   <div id="widget-3" class="yz-widget" role="complementary">
					<?php if ( ! dynamic_sidebar( 'sidebar-3' ) ) : ?>

						<?php
						the_widget( 'Twenty_Eleven_Ephemera_Widget', '', array( 'before_title' => '<h3 class="widget-title">', 'after_title' => '</h3>' ) );
						?>

					<?php endif; // end sidebar widget area ?>
			   </div><!-- .widget-area -->

			   <div id="widget-4" class="yz-widget" role="complementary">
					<?php if ( ! dynamic_sidebar( 'sidebar-4' ) ) : ?>

						<?php
						the_widget( 'Twenty_Eleven_Ephemera_Widget', '', array( 'before_title' => '<h3 class="widget-title">', 'after_title' => '</h3>' ) );
						?>

					<?php endif; // end sidebar widget area ?>
			   </div><!-- .widget-area -->

			   <div id="widget-5" class="yz-widget" role="complementary">
					<?php if ( ! dynamic_sidebar( 'sidebar-5' ) ) : ?>

						<?php
						the_widget( 'Twenty_Eleven_Ephemera_Widget', '', array( 'before_title' => '<h3 class="widget-title">', 'after_title' => '</h3>' ) );
						?>

					<?php endif; // end sidebar widget area ?>
			   </div><!-- .widget-area -->
            </div><!--widget-->

				<?php endwhile; // end of the loop. ?>

<?php get_footer(); ?>