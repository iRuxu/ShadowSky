<?php
/**
 * Template Name: Search Page
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package WordPress
 * @subpackage Twenty_Eleven
 * @since Twenty Eleven 1.0
 */

get_header(); ?>
<div id="g-search-top" style="margin:0 auto;padding:2px 20px;">


<form action="http://www.shadowsky.cn/search/" id="cse-search-box">
  <div>
    <input type="hidden" name="cx" value="partner-pub-7634555036659066:3473727169" />
    <input type="hidden" name="cof" value="FORID:10" />
    <input type="hidden" name="ie" value="UTF-8" />
    <input type="text" name="q" size="60" />
    <input type="submit" name="sa" value="&#x641c;&#x7d22;" />
  </div>
</form>
<script type="text/javascript" src="http://www.google.com/jsapi"></script>
<script type="text/javascript">google.load("elements", "1", {packages: "transliteration"});</script>
<script type="text/javascript" src="http://www.google.com/cse/t13n?form=cse-search-box&t13n_langs=am%2Cml%2Cta%2Cpa%2Cel%2Cgu%2Car%2Cru%2Cmr%2Cte%2Cti%2Csa%2Cne%2Chi%2Cbn%2Cen%2Ckn%2Cfa%2Csr%2Cur"></script>

<script type="text/javascript" src="http://www.google.com.hk/coop/cse/brand?form=cse-search-box&amp;lang=zh-Hans"></script>
</div>

<div id="cse-search-results" style="padding:5px 15px;"></div>
<script type="text/javascript">
  var googleSearchIframeName = "cse-search-results";
  var googleSearchFormName = "cse-search-box";
  var googleSearchFrameWidth = 800;
  var googleSearchDomain = "www.google.com.hk";
  var googleSearchPath = "/cse";
</script>
<script type="text/javascript" src="http://www.google.com/afsonline/show_afs_search.js"></script>

<?php get_footer(); ?>