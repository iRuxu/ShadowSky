<?php
/**
 * Template Name: WG-X
 * Description: 带自定义侧边
 *
 * @package WordPress
 * @subpackage Twenty_Eleven
 * @since Twenty Eleven 1.0
 */

get_header(); ?>

		<div id="primary" class="entry-content">
			<div id="content" role="main">

				<?php the_post(); ?>

				<?php get_template_part( 'content', 'page' ); ?>

			</div><!-- #content -->
		</div><!-- #primary -->

        <div id="secondary" class="widget-area" role="complementary">
					<!-- .TIY -->
		</div><!-- .widget-area -->   


<?php get_footer(); ?>