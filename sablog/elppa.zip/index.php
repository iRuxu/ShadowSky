<!--<?php
if(!defined('SABLOG_ROOT')) {
	exit('Access Denied');
}
$current_page_item = array();
if (in_array($action, array('index', 'finduser', 'tags'))) {
	$current_page_item['index'] = ' class="current_page_item"';
} elseif (in_array($action, array('archives', 'tagslist', 'comments', 'trackbacks', 'search', 'links', 'wap'))) {
	$current_page_item[$action] = ' class="current_page_item"';
}

if ($_GET['action'] == 'show')
{ 
	$wrap = "wrap_width";
}
else 
{
	$wrap = "wrap";
}

print <<<EOT
-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Language" content="utf-8" />
<meta http-equiv="Pragma" content="no-cache" />
<meta name="keywords" content="4ngel,4ngel.net,安全,天使,安全天使,技术,黑客,网络,原创,论坛,自由,严肃,网络安全,组织,系统安全,系统,windows,web,web安全,web开发,$options[meta_keywords]" />
<meta name="description" content="4ngel,4ngel.net,安全,天使,安全天使,技术,黑客,网络,原创,论坛,自由,严肃,网络安全,组织,系统安全,系统,windows,web,web安全,web开发,$options[meta_description]" />
<meta name="copyright" content="SaBlog" />
<meta name="author" content="angel,4ngel" />
<link rel="alternate" title="$options[name]" href="rss.php" type="application/rss+xml" />
<link rel="stylesheet" href="templates/$options[templatename]/style.css" type="text/css" media="all" />
<script type="text/javascript">
	var postminchars = parseInt("$options[comment_min_len]");
	var postmaxchars = parseInt("$options[comment_max_len]");
</script> 
<script type="text/javascript" src="include/common.js"></script>
<!-- 下面这几个js放到common.js上面居然就不能用，我日！ -->
<script src="templates/$options[templatename]/js/prototype.js" type="text/javascript"></script>
<script src="templates/$options[templatename]/js/scriptaculous.js" type="text/javascript"></script>
<script src="templates/$options[templatename]/js/unittest.js" type="text/javascript"></script> 


<title>$options[title] $options[title_keywords] - Powered by Sablog-X</title>
</head>
<body>
<div id="header">
   <ul class="menu">
        <li{$current_page_item[index]}><a href="./">Home</a></li>
        <li{$current_page_item[archives]}><a href="./?action=archives">Archives</a></li>
        <li{$current_page_item[search]}><a href="./?action=search">Search</a></li>
        <li{$current_page_item[tagslist]}><a href="./?action=tagslist">Tags</a></li>
        <li{$current_page_item[comments]}><a href="./?action=comments">Comments</a></li>
      <!--
EOT;

if ($options['enable_trackback']) {print <<<EOT
-->
        <li{$current_page_item[trackbacks]}><a href="./?action=trackbacks">Trackbacks</a></li>
      <!--
EOT;
}print <<<EOT
-->
        <li{$current_page_item[links]}><a href="./?action=links">Links</a></li>
		<li{$current_page_item[wap]}><a href="wap/" target="_blank" title="手机浏览">Wap</a></li>
	</ul> 

	<ul class="sub_menu">
	<li><a href="#" title="分类">Category:</a></li>
<!--
EOT;
	foreach($catecache AS $data){
print <<<EOT
-->
      <li><a href="./?action=index&amp;cid=$data[cid]">$data[name]</a><!-- <a href="./rss.php?cid=$data[cid]" target="_blank" title="RSS 2.0 订阅这个分类"> <img src="templates/$options[templatename]/img/rss.gif" border="0" alt="RSS 2.0 订阅这个分类" /></a> <span>[$data[articles]]</span> --></li>
      <!--
EOT;
}print <<<EOT
-->
	</ul>

</div>
<div id="outmain">

<div id="topmenu"> 
<div class="top_top">
<span class="rss2">
<!--
EOT;
 if ($options['rss_enable']) {print <<<EOT
-->
      <a href="rss.php" target="_blank" title="RSS 2.0 订阅"><img src="templates/$options[templatename]/img/rss.gif" border="0" alt="RSS 2.0 订阅" /> &nbsp; RSS FEED </a>  
      <!--
EOT;
}print <<<EOT
-->
</span>
 <h1><a href="$options[url]">$options[name]</a></h1> 
 </div>

  <span id="description">
  $options[description]
  </span>

  <span id="guestlink">
    <!--
EOT;
if ($sax_uid) {print <<<EOT
-->
    Welcome，$sax_user &raquo; <a href="?action=profile">Profile</a> | <a href="post.php?action=logout">Logout</a>
<!--
EOT;
if ($sax_group == 1 || $sax_group == 2) {print <<<EOT
--> | <a href="admin/admincp.php" target="_blank">Admin</a>
<!--
EOT;
}}else{print <<<EOT
-->
     <a href="./?action=login">Login</a> | <a href="./?action=reg">Join</a>
    <!--
EOT;
}print <<<EOT
-->
  </span>

</div>
<div id="page">
  <div id="$wrap">
<!--
EOT;
require_once PrintEot($pagefile);
print <<<EOT
-->
  </div>
<!--
EOT;
	if ($_GET['action'] <> 'show')
	{
print <<<EOT
-->
  <div id="sidebar"> 
  <div id="search">
<!--   <h2>Search</h2> -->
<!--
EOT;
print <<<EOT
-->
<!--     <h2>Entries</h2> -->
    <form method="post" action="post.php">
      <input type="hidden" name="formhash" value="$formhash" />
      <input type="hidden" name="action" value="search" />
      <p><input class="formfield" maxlength="30" size="17" name="keywords" onfocus="this.value=''" onblur="this.value='Search Articles'" value="Search Articles" /><button type="submit" class="go"> </button></p>
		<!-- <p><a href="./?action=search">高级搜索</a></p> -->
    </form>
    <!--
EOT;
if($options['allow_search_comments'] && $_GET['viewmode'] <> 'list'){print <<<EOT
-->
<!--     <h2>Comments</h2> -->
    <form method="post" action="post.php">
      <input type="hidden" name="formhash" value="$formhash" />
      <input type="hidden" name="action" value="search" />
      <input type="hidden" name="searchfrom" value="comment" />
      <p><input class="formfield" maxlength="30" size="17" name="keywords" onfocus="this.value=''" onblur="this.value='Search Comments'" value="Search Comments" /><button type="submit" class="go"> </button></p>
      <!--  <p>匹配评论人和内容</p> -->
    </form>
    <!--
EOT;
}print <<<EOT
-->
</div>
<!--
EOT;
if ($options['hottags_shownum']) {print <<<EOT
-->
    <h2>Hot Tags</h2>
    <ul class="tags_icon">
      <!--
EOT;
if(empty($tagcache)){print <<<EOT
-->
      <li>没有任何标签</li>
      <!--
EOT;
}else{
foreach($tagcache AS $data){
print <<<EOT
-->
      <li><a href="./?action=tags&amp;item=$data[url]">$data[tag]</a> <span>[$data[usenum]]</span></li>
      <!--
EOT;
}}print <<<EOT
-->
    </ul>
    <!--
EOT;
}
if ($options['show_archives']) {print <<<EOT
-->
    <h2>Archives</h2>
    <ul class="archives_icon">
      <!--
EOT;
if(empty($archivecache)){print <<<EOT
-->
      <li>没有任何归档</li>
      <!--
EOT;
}else{
if (is_numeric($options['archives_num']) && $options['archives_num']) {
	$archivecache = array_slice($archivecache,0,$options['archives_num']);
}
foreach($archivecache AS $key => $val){
$v = explode('-', $key);
//$e_month = ($v[1] < 10) ? str_replace('0', '', $v[1]) : $v[1];
print <<<EOT
-->
      <li><a href="./?action=index&amp;setdate=$v[0]$v[1]">{$v[0]}年{$v[1]}月</a> <span>[$val]</span></li>
      <!--
EOT;
}}print <<<EOT
-->
    </ul>
<!--
EOT;
if (is_numeric($options['archives_num']) && $options['archives_num']) {print <<<EOT
-->
   <!--  <p class="more"><a href="./?action=archives">更多</a></p> -->
    <!--
EOT;
}}
print <<<EOT
-->
 	<h2>Advertisement</h2>
	<p>you can add an advertisement here</p>
  </div>
</div> 
<!--
EOT;
}
?>-->