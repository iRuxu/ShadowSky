<!--<?php
if(!defined('SABLOG_ROOT')) {
	exit('Access Denied');
}
if ($stats['attachment_count']) {print <<<EOT
-->
<table width="100%" border="0" cellspacing="5" cellpadding="5">
  <tr>
    <td bgcolor="#F3F7FA" colspan="$rows[0]"><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><strong>附件展区</strong></td>
    <td align="right"><a href="./?action=attachment">全部</a> | <a href="./?action=attachment&amp;type=file">文件</a> | <a href="./?action=attachment&amp;type=image">图片</a></td>
  </tr>
</table></td>
<!--
EOT;
$row=-1;
foreach($attachdb as $key => $attach){
$row++;
if($row % $rows[0] == 0) {print <<<EOT
--></tr><tr>
<!--
EOT;
}
print <<<EOT
-->
    <td bgcolor="#F3F7FA">
	  <div class="attachicon">$attach[attachicon]</div>
      <div class="attachttitle">$attach[filename]</div>
      <div class="attachdesc">文件字节: $attach[filesize] Bytes<br />
        MIME类型: $attach[filetype]<br />
        上传时间: $attach[dateline]</div>
      <div><!--
EOT;
if ($attach['articleid']) {print <<<EOT
-->
<a href="./?action=show&amp;id=$attach[articleid]" title="$attach[title]">查看文章</a>
<!--
EOT;
}print <<<EOT
--><a href="./attachment.php?id=$attach[attachmentid]" target="_blank">下载此附件</a> [<font color="#FF6600">$attach[downloads]</font>]</div></td>
<!--
EOT;
}
print <<<EOT
-->
  </tr>
</table>
$multipage
<!--
EOT;
} else {print <<<EOT
-->
<p><strong>没有任何附件</strong></p>
<!--
EOT;
}
?>
