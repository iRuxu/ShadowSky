<div class="footer"><br />
	<ul>
	<?php wp_register(); ?> <li>| 
	<?php wp_loginout(); ?></li> 
	<li>| <a href="<?php bloginfo('rss2_url'); ?>">Entries (RSS)</a></li> 
	<li>| <a href="<?php bloginfo('comments_rss2_url'); ?>">Comments (RSS)</a></li> 
	<li>| <a href="http://validator.w3.org/check/referer" title="This page validates as XHTML 1.0 Transitional">Valid <abbr title="eXtensible HyperText Markup Language">XHTML</abbr></a><?php wp_meta(); ?></li>
	</ul><br />
	<ul>
	<li>Powered by <a href="http://www.wordpress.org" target="_blank">Wordpress</a>|Design by <a href="http://www.shadowsky.cn" target="_blank">Shadow.V.B</a></li>
		<!-- <?php echo get_num_queries(); ?> queries. <?php timer_stop(1); ?> seconds. -->
	</ul>
<!-- Purple Princess | Design by Shadow.V.B (http://www.shadowsky.cn) |FireFox/IE6/Oprea |1024*768/1280*1024 -->
<?php /* "Just what do you think you're doing Dave?" */ ?>
		<?php wp_footer(); ?>
		</div>
		</div>
</body>
</html>
