<!--<?php
if(!defined('SABLOG_ROOT')) {
	exit('Access Denied');
}
print <<<EOT
-->
<h2 class="title">全部评论</h2>
<!--
EOT;
if ($tatol) {
$comment_style = 'comment';
foreach($commentdb as $key => $comment){
	if ($comment_style == 'comment') {
		$comment_style = 'comment_alt';
	}
	else {
		$comment_style = 'comment';
	}
print <<<EOT
--><div class="$comment_style">
<h2 class="art-title"><a href="./?action=show&amp;id=$comment[articleid]">$comment[title]</a></h2> 
<div class="lesscontent">$comment[content]</div>
<span class="lessdate">Post by $comment[author] on $comment[dateline]</span>
<p style="clear:both;"></p>
</div>
<!--
EOT;
}print <<<EOT
-->
$multipage
<!--
EOT;
} else {print <<<EOT
-->
<p><strong>没有任何评论</strong></p>
<!--
EOT;
}
?>