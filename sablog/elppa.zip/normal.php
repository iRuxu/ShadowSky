<!--<?php
if(!defined('SABLOG_ROOT')) {
	exit('Access Denied');
}
print <<<EOT
-->
<script type="text/javascript">
window.onload=function(){ 
	fiximage('$options[attachments_thumbs_size]');
}
</script>
<div id="top"><span>浏览模式: 标准 | <a href="./?viewmode=list{$modelink}">列表</a></span>$navtext &raquo;</div>
<div id="main">
<!--
EOT;
if ($tatol) {
foreach($articledb as $key => $article){
print <<<EOT
--><h2 class="posttitle"><a href="./?action=show&amp;id=$article[articleid]"><!--
EOT;
if($article['stick']){
print <<<EOT
--><span style="font-weight:normal;">[置顶]</span> <!--
EOT;
}
print <<<EOT
-->$article[title]</a></h2>
<p class="postdate">Submitted by <a href="./?action=finduser&amp;userid=$article[uid]">$article[username]</a> on $article[dateline]</p><!--
EOT;
if (!$article['allowread']) {print <<<EOT
-->
<div class="needpwd"><form action="./?action=show&amp;id=$article[articleid]" method="post">这篇日志被加密了，请输入密码后查看。<br /><input class="formfield" type="password" name="readpassword" style="margin-right:5px;" /> <button class="formbutton" type="submit">提交</button></form></div>
<!--
EOT;
} else {print <<<EOT
-->
<div class="content">$article[content]
<!--
EOT;
if ($article['description']) {print <<<EOT
-->
<p>&raquo; <a href="./?action=show&amp;id=$article[articleid]">阅读全文</a></p>
<!--
EOT;
}print <<<EOT
--></div>
<!--
EOT;
if ($options['attachments_display'] == 0) {
if ($article['image']) {
foreach ($article['image'] as $image) {
if($image[6]){print <<<EOT
--><p class="attach">图片附件(缩略图):<br /><a href="attachment.php?id=$image[0]" target="_blank"><img src="$image[1]" border="0" alt="大小: $image[2]&#13;尺寸: $image[3] x $image[4]&#13;浏览: $image[5] 次&#13;点击打开新窗口浏览全图" width="$image[3]" height="$image[4]" /></a></p>
<!--
EOT;
} else {print <<<EOT
--><p class="attach">图片附件:<br /><a href="attachment.php?id=$image[0]" target="_blank"><img src="$image[1]" border="0" alt="大小: $image[2]&#13;尺寸: $image[3] x $image[4]&#13;浏览: $image[5] 次&#13;点击打开新窗口浏览全图" width="$image[3]" height="$image[4]" /></a></p>
<!--
EOT;
}}}
if($article['file']){
foreach($article['file'] as $file){
if($file){print <<<EOT
--><p class="attach"><strong>附件: </strong><a href="attachment.php?id=$file[0]" target="_blank">$file[1]</a> ($file[2], 下载次数:$file[3])</p>
<!--
EOT;
}}}} elseif ($options['attachments_display'] == 1) {
$imagenum = count($article['image']);
$filenum = count($article['file']);
$attachnum = $filenum+$imagenum;
if ($attachnum != 0) {
print <<<EOT
--><p class="attach"><span class="attach-desc">本文有${attachnum}个附件 (图片:$imagenum, 文件:$filenum)</span></p>
<!--
EOT;
}}
if ($article['keywords']) {
print <<<EOT
--><p class="tags"><span>Tags</span>: $article[alltags]</p><!--
EOT;
}
print <<<EOT
--><p class="postmetadata"><span class="span_left"><a href="./?action=index&amp;cid=$article[cid]">$article[cname]</a></span><span class="span_right"> | <a href="./?action=show&amp;id=$article[articleid]#comment">评论</a>:$article[comments]
<!--
EOT;
if ($options['enable_trackback']) {print <<<EOT
--> | <a href="./?action=show&amp;id=$article[articleid]#trackbacks">Trackbacks</a>:$article[trackbacks]
<!--
EOT;
}print <<<EOT
--> | <a href="./?action=show&amp;id=$article[articleid]">阅读</a>:$article[views]</span></p>
<!--
EOT;
}}print <<<EOT
-->
$multipage
<!--
EOT;
} else {print <<<EOT
-->
<p><strong>没有任何文章</strong></p>
<!--
EOT;
}
print <<<EOT
-->
	</div>
	<div id="extend">
<!--
EOT;
if ($options['show_calendar']) {print <<<EOT
-->
<div id="calendar">
<table cellpadding="0" cellspacing="1">
  <tr align="center">
    <td colspan="7" class="curdate"><a href="./?action=index&amp;setdate=$calendar[prevmonth]">&laquo;</a> $calendar[cur_date] <a href="./?action=index&amp;setdate=$calendar[nextmonth]">&raquo;</a></td>
  </tr>
  <tr>
    <th class="week">Su</th>
    <th class="week">Mo</th>
    <th class="week">Tu</th>
    <th class="week">We</th>
    <th class="week">Th</th>
    <th class="week">Fr</th>
    <th class="week">Sa</th>
  </tr>
  $calendar[html]
</table>
</div>
    <!--
EOT;
}
if ($options['show_statistics']) {print <<<EOT
-->
    <h2>Stat.</h2>
    <ul class="sidebar_stat">
      <li>分类数量: <span class="num">$stats[cate_count]</span></li>
      <li>文章数量: <span class="num">$stats[article_count]</span></li>	
	  <li>评论数量: <span class="num">$stats[comment_count]</span></li>
      <li>标签数量: <span class="num">$stats[tag_count]</span></li>
      <li>附件数量: <span class="num">$stats[attachment_count]</span></li>
      <!--
EOT;
if ($options['enable_trackback']) {print <<<EOT
-->
      <li>引用数量: <span class="num">$stats[trackback_count]</span></li>
      <!--
EOT;
}print <<<EOT
-->
      <li>用户数量: <span class="num">$stats[user_count]</span></li>
      <li>今日访问: <span class="num">$stats[today_view_count]</span></li>
	  <li>总访问量: <span class="num">$stats[all_view_count]</span></li>
      <li>程序版本: <span class="num">$SABLOG_VERSION</span></li>
	</ul>
    <!--
EOT;
}
if ($options['sidebarlinknum']) {print <<<EOT
-->
    <h2 class="Links" style="cursor: pointer" onclick="Effect.toggle('Links','slide'); return false;"><a href="#">Links</a></h2> 
	<div id="Links">
    <ul class="sidebar_links">
      <!--
EOT;
if(!$linkcache){print <<<EOT
-->
      <li><a href="http://www.4ngel.net" target="_blank" title="安全天使网络安全小组">S4T</a></li>
      <li><a href="http://www.sablog.net" target="_blank" title="Sablog-X官方网站">Sablog-X</a></li>
      <li><a href="http://www.sablog.net/blog" target="_blank" title="angel's blog">angel's blog</a></li>
      <!--
EOT;
}else{
foreach($linkcache AS $data){
print <<<EOT
-->
      <li><a href="$data[url]" target="_blank" title="$data[note]">$data[name]</a></li>
      <!--
EOT;
}}print <<<EOT
-->
    </ul> </div>
	<!--
EOT;
if ($link_count > $options['sidebarlinknum']) {print <<<EOT
-->
    <p class="more"><a href="./?action=links"><span>更多</span></a></p> 
	
	<!--
EOT;
}} 
if ($options['recentcomment_num']) {print <<<EOT
--> 
    <h2>New Comments</h2>
    <ul class="sidebar_comments">
      <!--
EOT;
if(empty($newcommentcache)){print <<<EOT
-->
      <li>没有任何评论</li>
      <!--
EOT;
}else{
foreach($newcommentcache AS $data){
$data[content] = stripslashes_array($data[content]);
print <<<EOT
-->
      <li><span>$data[dateline] - $data[author]</span><br /><a href="./?action=show&amp;id=$data[articleid]&amp;cmid=$data[commentid]&amp;goto=newcm">$data[content]</a></li>
      <!--
EOT;
}}print <<<EOT
-->
    </ul>
    <p class="more"><a href="./?action=comments"><span>&nbsp;</span></a></p>
    <!--
EOT;
}
print <<<EOT
-->

	</div>
<!--
EOT;
?>