<div class="sidebar">
<div id="search"><?php include (TEMPLATEPATH . '/searchform.php'); ?></div>	
<div id="purpleprincess"><div id="svbphoto"><a href="http://www.shadowsky.cn/yz/photo/"><img src="http://www.shadowsky.cn/img/me.jpg"></a></div>
Name:源子/Shadow/Shadow.V.B<br />
Current Location:长沙@China<br />
Birth:1987/05/12<br />
shadowblue525@gmail.com<br />
<a href="http://www.shadowsky.cn/blog">&raquo; My old blog (Just for view)</a><br />
<a href="https://domains.live.com/members/signup.aspx?domain=shadowsky.cn" target="_blank" title="Get a 1G free mail like ******@shadowsky.cn">[Get ******@shadowsky.cn !]</a><br /><br /><br />
Shadow is not just a shadow,records of my life in my sky.-Shadow's sky
</div>
<div id="category"><?php wp_list_categories('show_count=1&title_li=<h2>Category</h2>'); ?></div>
<div id="pages"><?php wp_list_pages('title_li=<h2>Navigation</h2>' ); ?></div>
<div id="link"><?php wp_list_bookmarks('title_li=<h2>Link</h2>'); ?></div>
<div id="magic-link"><h2>Link</h2>
<ul>
<li><a href="" target="_blank" title="">+ Magic Cursor</a></li>
<li><a href="" target="_blank" title="">+ Magic Brush</a></li>
<li><a href="" target="_blank" title="">+ Magic Style</a></li>
<li><a href="" target="_blank" title="">+ Magic Pattern</a></li>
<li><a href="" target="_blank" title="">+ Magic Player</a></li>
<li><a href="" target="_blank" title="">+ Magic Font</a></li>
<li><a href="" target="_blank" title="">+ Magic PS-Plugin</a></li>
<li><a href="" target="_blank" title="">+ Magic Forum</a></li>
<li><a href="" target="_blank" title="">+ RSS Feed</a></li>
<li><a href="" target="_blank" title="">+ S.V.B Studio</a></li>
<li><a href="" target="_blank" title="">+ Site Map</a></li>
<ul>
</div>
<div id="archive"><?php /* If this is a 404 page */ if (is_404()) { ?>
	<?php /* If this is a category archive */ } elseif (is_category()) { ?>
			<span>You are currently browsing the archives for the <?php single_cat_title(''); ?> category</span>
			<?php /* If this is a yearly archive */ } elseif (is_day()) { ?>
			<span>You are currently browsing the <a href="<?php bloginfo('home'); ?>/"><?php echo bloginfo('name'); ?></a> weblog archives</span>
			for the day <?php the_time('l, F jS, Y'); ?>.
			<?php /* If this is a monthly archive */ } elseif (is_month()) { ?>
			<span>You are currently browsing the <a href="<?php bloginfo('home'); ?>/"><?php echo bloginfo('name'); ?></a> weblog archives
			for <?php the_time('F, Y'); ?>.</span>
			<?php /* If this is a yearly archive */ } elseif (is_year()) { ?>
			<span>You are currently browsing the <a href="<?php bloginfo('home'); ?>/"><?php echo bloginfo('name'); ?></a> weblog archives
			for the year <?php the_time('Y'); ?>.</span>
			<?php /* If this is a monthly archive */ } elseif (is_search()) { ?>
			<span>You have searched the <a href="<?php echo bloginfo('home'); ?>/"><?php echo bloginfo('name'); ?></a> weblog archives
			for <strong>'<?php the_search_query(); ?>'</strong>. If you are unable to find anything in these search results, you can try one of these links.</span>
			<?php /* If this is a monthly archive */ } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?>
			<span>You are currently browsing the <a href="<?php echo bloginfo('home'); ?>/"><?php echo bloginfo('name'); ?></a> weblog archives.</span>
			<?php } ?>
	<br /><h2>Archives</h2><ul><?php wp_get_archives('type=monthly'); ?></ul><br /></div>
<?php /* If this is the frontpage */ if ( is_home() || is_page() ) { ?>
<?php } ?>
</div>
</div>