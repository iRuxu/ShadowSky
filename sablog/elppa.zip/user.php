<!--<?php
if(!defined('SABLOG_ROOT')) {
	exit('Access Denied');
}
print <<<EOT
-->
<p class="title">用户</p>
<div class="post">
<!--
EOT;
foreach($userdb as $key => $user){
print <<<EOT
-->
  <a name="$user[adminid]"></a>
  <div style="border-bottom:1px solid #d6e3ef;background-color: #F3F7FA;margin-bottom: 15px;padding:10px 0px;">
    <table cellspacing="0" cellpadding="10" width="100%" border="0">
      <tr>
        <td width="30%" align="center" valign="top"><table border="0" cellspacing="0" cellpadding="3" class="avatar">
            <tr>
              <td><img alt="$user[nickname]" src="$user[face]" width="100" height="100" border="0" /></td>
            </tr>
          </table>
          <br />
          <a href="./?action=finduser&amp;userid=$user[adminid]">$user[articles]篇文章</a></td>
        <td width="70%" align="left" valign="top"><span style="font-size:14px;font-weight: bold;">$user[nickname]</span>
          <p>E-mail: $user[email]</p>
          $user[signature]</td>
      </tr>
    </table>
  </div>
<!--
EOT;
}print <<<EOT
-->
</div>
<!--
EOT;
?>
