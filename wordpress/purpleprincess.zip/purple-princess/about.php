<?php
/*
Template Name: about
*/
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<title><?php bloginfo('name'); ?> - About</title>
<meta name="generator" content="WordPress <?php bloginfo('version'); ?>" /> <!-- leave this for stats -->
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<?php wp_head(); ?>
</head>
<body>
<div class="main">
<div id="header">
		<h1><a href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a></h1>
		<div class="description"><?php bloginfo('description'); ?></div>
</div>
<div class="nav"><ul>
<li><a href="<?php echo get_option('home'); ?>/">Home</a></li>
<li><a id="nav-about" href="<?php echo get_option('home'); ?>/about/">About</a></li>
<li><a href="<?php echo get_option('home'); ?>/works/">Works</a></li>
<li><a href="<?php echo get_option('home'); ?>/photo/">Photo</a></li>
<li><a href="<?php echo get_option('home'); ?>/links/">Links</a></li>
<li><a href="http://bbs.yuanzi.name/index.php?fromuid=2" target="_blank">Forum</a></li>
</ul></div>
<div class="wapper">
<div class="svbshow">
<ul>
  <li class="s1"><a href="#"><span>love yuanzi</span></a></li>
  <li class="s2"><a href="#"><span>love yuanzi</span></a></li>
  <li class="s3"><a href="#"><span>love yuanzi</span></a></li>
  <li class="s4"><a href="#"><span>love yuanzi</span></a></li>
  <li class="s5"><a href="#"><span>love yuanzi</span></a></li>
</ul>
</div>
<div class="aboutpage">
<div class="aboutpage" id="aboutme">
<h6>|| About the webmaster</h6>
Name:源子(Shadow/S.V.B/YZ)<br />
Sex:Girl<br />
Birth:1987/05 [Rabbit]<br />
Constellation:Taurus<br />
Current Location:Changsha.Hunan.China<br />
Now:Changsha University of science & technology<br />
MSN:shadowblue525@hotmail.com<br />
E-Mail:shadowblue525@gmail.com<br />
Be good at:Piano,Web design<br />
Hight:162cm<br />
Weight:45kg<br />
<strong><a href="http://www.shadowsky.cn/test/jl/me.html">View my curriculum vitae</a></strong>
</div>
<div class="aboutpage" id="aboutme">
<h6>|| My Working Environment</h6>
&raquo; Hardware<br />
<small>+Home: lenovo 联想锋行 X7010 PD915 1024160sG</small><br />
<small>+School: ......</small><br />
&raquo; Software<br />
<small>Editplus,Photoshop,Illustrator,AutoFX,Ulead-X</small><br />
</div>
<div class="aboutpage" id="aboutme">
<h6>|| About the ShadowSky</h6>
<font color="#7d09b0">声明: 在没有特殊注明的情况下,本站所有资源(图文)均为原创.在未经本人许可下禁止对任何内容进行转载.</font><br />
<font color="#7d09b0">Statement: All the entries and pictures are owned by shadowsky.cn .You have no right to reprinted them before you get the author's permission!</font> <br />
[2000-2001] 影子的天空<br />
<small>(ChinaRen/其它免费空间)http://rx6.126.com</small><br />
[2002-2004] ShadowBlue<br />
<small>(网易X收费空间+互动力量社区)http://shadowblue.nease.163.com</small><br />
[2004-2005] ShadowSky<br />  
<small>(MSN空间+网易日记本)</small><br />
[2006/02/04] ☆ShadowSky☆<br />
<small>(腾翼网) http://www.shadowsky.cn</small><br />
[2007/03/06] Purple Princess<br /> 
<small>(梦游科技) http://www.yuanzi.name</small><br />
</div>
</div>
</div>

<?php get_footer(); ?>
