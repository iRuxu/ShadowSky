<?php
/**
 * Template Name: Coreldraw Book
 * Description: Coreldraw教程页面
 *
 * @package WordPress
 * @subpackage Twenty_Eleven
 * @since Twenty Eleven 1.0
 */

get_header(); ?>

		<div id="primary">
			<div id="content-page" role="main">

				<?php the_post(); ?>

				<?php get_template_part( 'content', 'page' ); ?>

			</div><!-- #content -->
		</div><!-- #primary -->

        <div id="coreldraw-book" role="complementary">
                    <div id="coreldraw-0">
					<a href="http://www.shadowsky.cn/download/coreldraw/coreldrawX5.chm" target="_blank">
					<img src="http://www.shadowsky.cn/img/product/coreldraw/0.png" alt="CorelDRAW X5 SP3中文版最新官方帮助手册" title="CorelDRAW X5 SP3中文版最新官方帮助手册"/>
					</a><br />					
					<span><a href="http://www.shadowsky.cn/download/coreldraw/coreldrawX5.chm" target="_blank"><h1>下载至手机iReader阅读</h1></a></span>
                    <br />
					</div>

					<div id="coreldraw-1">
					<a href="http://www.amazon.cn/mn/detailApp/ref=as_li_tf_tl?_encoding=UTF8&tag=shadowblue525-23&linkCode=as2&asin=B0041IV73G&camp=536&creative=3200&creativeASIN=B0041IV73G" target="_blank">
					<img src="http://www.shadowsky.cn/img/product/coreldraw/1.png" alt="CorelDRAW X5中文版标准教程" title="CorelDRAW X5中文版标准教程" />
					</a><br />					
					<span><a href="http://www.amazon.cn/mn/detailApp/ref=as_li_tf_tl?_encoding=UTF8&tag=shadowblue525-23&linkCode=as2&asin=B0041IV73G&camp=536&creative=3200&creativeASIN=B0041IV73G" target="_blank"><h1>CorelDRAW X5中文版<br/>标准教程（附DVD光盘1张）</h1></a></span>
                    <span>「Corel公司指定标准教材」</span>
					</div>
					<div id="coreldraw-2">
					<a href="http://www.amazon.cn/mn/detailApp/ref=as_li_tf_tl?_encoding=UTF8&tag=shadowblue525-23&linkCode=as2&asin=B004NG95V2&camp=536&creative=3200&creativeASIN=B004NG95V2" target="_blank">
					<img src="http://www.shadowsky.cn/img/product/coreldraw/2.png" alt="CorelDRAW X5平面广告设计经典108例" title="CorelDRAW X5平面广告设计经典108例"/>
					</a><br />
					<a href="http://www.amazon.cn/mn/detailApp/ref=as_li_tf_tl?_encoding=UTF8&tag=shadowblue525-23&linkCode=as2&asin=B004NG95V2&camp=536&creative=3200&creativeASIN=B004NG95V2" target="_blank">CorelDRAW X5平面广告设计<br />经典108例(附DVD光盘1张)</a>
					</div>
					<div id="coreldraw-3">
					<a href="http://www.amazon.cn/mn/detailApp/ref=as_li_tf_tl?_encoding=UTF8&tag=shadowblue525-23&linkCode=as2&asin=B004HIMA1S&camp=536&creative=3200&creativeASIN=B004HIMA1S" target="_blank">
					<img src="http://www.shadowsky.cn/img/product/coreldraw/3.png" alt="最新CorelDRAW X5中文版标准教程" title="最新CorelDRAW X5中文版标准教程"/>
					</a><br />
					<a href="http://www.amazon.cn/mn/detailApp/ref=as_li_tf_tl?_encoding=UTF8&tag=shadowblue525-23&linkCode=as2&asin=B004HIMA1S&camp=536&creative=3200&creativeASIN=B004HIMA1S" target="_blank">最新CorelDRAW X5中文版<br />标准教程(附CD光盘1张)</a>
					
					</div>
					<div id="coreldraw-4">
					<a href="http://www.amazon.cn/gp/bestsellers/books/660947051/?ie=UTF8&tag=shadowblue525-23&linkCode=ur2&camp=536&creative=3200" title="更多CorelDraw书籍">更多CorelDraw书籍</a></div>
					<div id="coreldraw-5"></div>
		</div><!-- .widget-area -->   


<?php get_footer(); ?>