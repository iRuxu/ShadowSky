<?php
/**
 * Template Name: Links
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package WordPress
 * @subpackage Twenty_Eleven
 * @since Twenty Eleven 1.0
 */

get_header(); ?>
<div id="page-content" class="entry-content">			
				<?php the_post(); ?>

				<?php get_template_part( 'contentx', 'page' ); ?>
                <div id="links-page-content">
                <?php wp_list_bookmarks('title_li=&category_before=&category_after='); ?>
				</div>    
</div>

<?php get_footer(); ?>