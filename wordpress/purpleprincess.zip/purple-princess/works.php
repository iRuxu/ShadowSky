<?php
/*
Template Name: works
*/
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<title><?php bloginfo('name'); ?> - Works</title>
<meta name="generator" content="WordPress <?php bloginfo('version'); ?>" /> <!-- leave this for stats -->
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<?php wp_head(); ?>
</head>
<body>
<div class="main">
<div id="header">
		<h1><a href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a></h1>
		<div class="description"><?php bloginfo('description'); ?></div>
</div>
<div class="nav"><ul>
<li><a href="<?php echo get_option('home'); ?>/">Home</a></li>
<li><a href="<?php echo get_option('home'); ?>/about/">About</a></li>
<li><a id="nav-works" href="<?php echo get_option('home'); ?>/works/">Works</a></li>
<li><a href="<?php echo get_option('home'); ?>/photo/">Photo</a></li>
<li><a href="<?php echo get_option('home'); ?>/links/">Links</a></li>
<li><a href="http://bbs.yuanzi.name/index.php?fromuid=2" target="_blank">Forum</a></li>
</ul></div>
<div style="clear:both; height:8px"></div>
<div class="wapper">

<div id="works" class="workspage">

	<ul>
	 <li id="gallery">
		<h6>Gallery</h6>
		<p>
			<span><a href="http://bbs.yuanzi.name/forumdisplay.php?fid=7&amp;page=1&amp;filter=type&amp;typeid=9" target="_blank">Brush|Style|Pattern|Mask|Filter|Plugin|Font|Cursor</a></span>
			<span class="shadow"><a href="..//yz/yuanzi/work/teach/photoshop/autofx/" target="_blank">AutoFX</a></span>
			<span><a href="#" target="_blank">undefined</a></span>
			<span class="shadow"><a href="..//yz/yuanzi/Work/Gallery/Illust/" target="_blank">View S.V.B's original illust</a></span>
			<span><a href="..//yz/yuanzi/Work/Gallery/Meterial/" target="_blank">View S.V.B's original meterial </a></span>
			<span class="shadow"><a href="..//yz/yuanzi/Work/Gallery/Wallpaper/" target="_blank">View S.V.B's original wallpapers</a></span>
			<span><a href="#" target="_blank">undefined</a></span>
		</p>
	 </li>

	 <li id="program">
		<h6>Program</h6>
		<p> 
		    <span><a href="..//yz/yuanzi/work/program/yz-board/" target="_blank">Download S.V.B's YY/YZ-Board skin</a></span>
			<span class="shadow"><a href="..//yz/yuanzi/work/program/wordpress/" target="_blank">Download S.V.B's Wordpress skin</a></span>
			<span><a href="..//yz/yuanzi/work/program/discuz/" target="_blank">Download S.V.B's Disucz skin</a></span>
			<span class="shadow"><a href="..//yz/yuanzi/work/program/sax/" target="_blank">Download S.V.B's Sablog-X skin</a></span>
			<span><a href="..//yz/yuanzi/work/program/boblog/" target="_blank">Download S.V.B's Bo-Blog skin</a></span>
			<span class="shadow"><a href="..//yz/yuanzi/work/program/blogcn/" target="_blank">Download S.V.B's Blogcn/Sina/Sohu/Other skin</a></span>
			<span><a href="..//yz/yuanzi/work/program/ss/" target="_blank">Download S.V.B's SuperSite skin</a></span>
		</p>
	 </li>

	 <li id="teach">
		 <h6>Teach</h6> 
		 <p>  
			<span><a href="..//yz/yuanzi/work/teach/css/" target="_blank">S.V.B版CSS教学系列</a></span>
			<span class="shadow"><a href="..//yz/yuanzi/work/teach/photoshop/" target="_blank">S.V.B PS教学系列</a></span>
			<span><a href="..//yz/yuanzi/work/teach/photoshop/autofx/" target="_blank">S.V.B AutoFX教学系列</a></span>
			<span class="shadow"><a href="..//yz/yuanzi/work/teach/javascript/" target="_blank">S.V.B JS教学系列</a></span>
			<span><a href="#" target="_blank">undefined</a></span>
			<span class="shadow"><a href="#" target="_blank">undefined</a></span>
			<span><a href="#" target="_blank">undefined</a></span>
		 </p> 
	 </li>
	</ul>

</div>

<div id="sy">

	<ul>
		<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/yz-board/2007-03-13/yaya/"><img src="..//blog/yaya1.gif" alt="YAYA" /></a></span></li>
		<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/sax/2007-03-13/green-x/"><img src="..//blog/greenx1.gif" alt="" /></a></span></li>
		<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/sax/2007-03-13/blue-sky/"><img src="..//blog/bluesky1.gif" alt="" /></a></span></li>
		<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/discuz/2007-03-13/simple-x/"><img src="..//blog/simplex1.gif" alt="" /></a></span></li>
		<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/blogcn/2007-03-13/korea-80-2/"><img src="..//blog/korea801.gif" alt="" /></a></span></li>
		<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-14/shadow-sky-ver8/"><img src="..//blog/shadowskyver81.gif" alt="" /></a></span></li>
		<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-14/shadow-sky-ver8/"><img src="..//blog/shadowskyver82.gif" alt="" /></a></span></li>
		<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-14/shadow-sky-ver8/"><img src="..//blog/shadowskyver83.gif" alt="" /></a></span></li>
		<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/sea-bubble/"><img src="..//blog/seabubble1.gif" alt="" /></a></span></li>
		<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/fairyland/"><img src="..//blog/fairyland1.gif" alt="" /></a></span></li>
		<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/shadowsky-ver7-template/"><img src="..//blog/shadowskyver71.gif" alt="" /></a></span></li>
		<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/monotone-purple-template/"><img src="..//blog/monopp1.gif" alt="" /></a></span></li>
		<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/feather/"><img src="..//blog/feather1.gif" alt="" /></a></span></li>
		<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/snow-of-christmas/"><img src="..//blog/snowofchristmas1.gif" alt="" /></a></span></li>
		<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/windmill/"><img src="..//blog/windmill1.gif" alt="" /></a></span></li>
		<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/ice-love/"><img src="..//blog/icelove1.gif" alt="" /></a></span></li>
		<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/blue-flower/"><img src="..//blog/blueflower1.gif" alt="" /></a></span></li>
		<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/future-nuptial-dress/"><img src="..//blog/dress1.gif" alt="" /></a></span></li>
		<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/vivid/"><img src="..//blog/vivid1.gif" alt="" /></a></span></li>
		<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/love-story/"><img src="..//blog/lovestory1.gif" alt="" /></a></span></li>
		<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/shadow-sea/"><img src="..//blog/shadowsea1.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/shadow-dream/"><img src="..//blog/shadowdream1.gif" alt="" /></a></span></li>
		<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/rosered/"><img src="..//blog/rosered1.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/korea-29/"><img src="..//blog/korea291.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/korea-29/"><img src="..//blog/korea292.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/korea-29/"><img src="..//blog/korea293.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/korea-29/"><img src="..//blog/korea294.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/korea-29/"><img src="..//blog/korea295.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/korea-29/"><img src="..//blog/korea296.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/korea-29/"><img src="..//blog/korea297.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/korea-29/"><img src="..//blog/korea298.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/korea-29/"><img src="..//blog/korea299.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/korea-29/"><img src="..//blog/korea2910.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/korea-29/"><img src="..//blog/korea2911.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/korea-29/"><img src="..//blog/korea2912.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/korea-29/"><img src="..//blog/korea2913.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/korea-29/"><img src="..//blog/korea2914.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/korea-29/"><img src="..//blog/korea2915.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/korea-29/"><img src="..//blog/korea2916.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/korea-29/"><img src="..//blog/korea2917.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/korea-29/"><img src="..//blog/korea2918.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/korea-29/"><img src="..//blog/korea2919.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/korea-29/"><img src="..//blog/korea2920.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/korea-29/"><img src="..//blog/korea2921.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/korea-29/"><img src="..//blog/korea2922.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/korea-29/"><img src="..//blog/korea2923.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/korea-29/"><img src="..//blog/korea2924.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/korea-29/"><img src="..//blog/korea2925.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/korea-29/"><img src="..//blog/korea2926.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/korea-29/"><img src="..//blog/korea2927.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/korea-29/"><img src="..//blog/korea2928.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/korea-29/"><img src="..//blog/korea2929.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-14/night-dream/"><img src="..//blog/nightdream1.gif" alt="" /></a></span></li>
<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/wordpress/2007-03-13/purple-princess/"><img src="..//blog/purpleprincess1.gif" alt="" /></a></span></li>
		<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/kosovo/"><img src="..//blog/kosovo1.gif" alt="" /></a></span></li>
		<li class="pic"><span class="right_shadow"><a href="..//yz/work/program/boblog/2007-03-13/blue-butterfly/"><img src="..//blog/bluebutterfly1.gif" alt="" /></a></span></li>
	</ul>

</div>
</div>
<?php get_footer(); ?>