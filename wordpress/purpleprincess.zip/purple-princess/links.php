<?php
/*
Template Name: Links
*/
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<title><?php bloginfo('name'); ?> - Links</title>
<meta name="generator" content="WordPress <?php bloginfo('version'); ?>" /> <!-- leave this for stats -->
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<script src="http://www.yuanzi.name/img/linktext.js" type=text/javascript></script>
<?php wp_head(); ?>
</head>
<body>
<div class="main">
<div id="header">
		<h1><a href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a></h1>
		<div class="description"><?php bloginfo('description'); ?></div>
</div>
<div class="nav"><ul>
<li><a href="<?php echo get_option('home'); ?>/">Home</a></li>
<li><a href="<?php echo get_option('home'); ?>/about/">About</a></li>
<li><a href="<?php echo get_option('home'); ?>/works/">Works</a></li>
<li><a href="<?php echo get_option('home'); ?>/photo/">Photo</a></li>
<li><a id="nav-links" href="<?php echo get_option('home'); ?>/links/">Links</a></li>
<li><a href="http://bbs.yuanzi.name/index.php?fromuid=2" target="_blank">Forum</a></li>
</ul></div>
<div class="wapper">

<div class="content">
<div id="yzlink">
<div class="linkcat" id="Relatives">
<h5>Relatives</h5>
<ul>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
</ul>
</div>

<div class="linkcat" id="Thanks">
<h5>Thanks</h5>
<ul>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
</ul>
</div>

<div class="linkcat" id="Friends">
<h5>Friends</h5>
<ul>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
</ul>
</div>

<div class="linkcat" id="YZ-Board">
<h5>Blog Roll</h5>
<ul>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
</ul>
</div>

<div class="sidebar">

<div id="bookmarklet">
<h5>links Category</h5>
<ul>
	<li><a href="http://www.yuanzi.name/yz/links#Relatives" title="">Relatives</a></li>
	<li><a href="http://www.yuanzi.name/yz/links#Thanks" title="">Thanks</a></li>
	<li><a href="http://www.yuanzi.name/yz/links#Friends" title="">Friends</a></li>
	<li><a href="http://www.yuanzi.name/yz/links#YZ-Board" title="">YZ-Board Roll</a></li>
</ul>
</div>

anoucement...

<div id="bookmarklet">
<h5>Bookmarklet</h5>
<ul>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="http://www.shadowsky.cn/" target="_blank" title="ShadowSky">ShadowSky</a></li>
<li><a href="#header">^top^</a></li>
</ul>
</div>
</div>

</div>

<?php get_footer(); ?>
